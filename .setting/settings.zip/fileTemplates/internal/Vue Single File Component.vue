<!--
  ~ Time:${DATE} ${TIME} ${SECOND}
  ~ Name:${FILE_NAME}
  ~ Path:${DIR_PATH}
  ~ ProjectName:${PROJECT_NAME}
  ~ Author:${USER}
  ~
  ~  Il n'ya qu'un héroïsme au monde : c'est de voir le monde tel qu'il est et de l'aimer.
  -->
  
<template>
  <div id="${COMPONENT_NAME}">
    #[[$END$]]#
  </div>
</template>

<script>
export default {
  name: "${COMPONENT_NAME}",
  data () {
    return {  }
  },
  components: {  },
}
</script>

<style scoped lang="less">
* {
  margin: 0;
  padding: 0;
  list-style: none;
  text-decoration: none;
}

a {
  &:link {
    color: #b700ff;
  }

  &:visited {
    color: #0066ff;
  }

  &:hover {
    color: #FF00FF;
  }

  &:active {
    color: #ff8800;
  }
}

ul:after {
  content: "";
  height: 0;
  clear: both;
  overflow: hidden;
  display: block;
  visibility: hidden;

  li {
    cursor: pointer;
    position: relative;
    list-style: none;
  }
}

// -------${COMPONENT_NAME}----------
#${COMPONENT_NAME} {

}
</style>