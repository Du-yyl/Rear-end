#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * time :${DATE} ${HOUR}:${MINUTE} ${SECOND}
 * ClassName :${NAME}
 * Package :${PACKAGE_NAME}
 * @author :${USER}
 * <p>
 * Il n'ya qu'un héroïsme au monde : 
 *  c'est de voir le monde tel qu'il est et de l'aimer.
 */
public class ${NAME} {
}
